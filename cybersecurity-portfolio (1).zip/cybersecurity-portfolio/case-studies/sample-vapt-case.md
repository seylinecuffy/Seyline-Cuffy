# 🧪 Case Study: Web Application Vulnerability Assessment

**Project Goal**  
Perform a security assessment of a mock e-commerce web application to identify vulnerabilities and propose remediation steps.

---

## 🔍 Scope

- Target: `http://test-ecommerce.local`
- In-Scope Modules: Login, Cart, Payment
- Out-of-Scope: Admin Panel

---

## 🛠 Tools Used

- `Burp Suite` (for manual testing and fuzzing)
- `OWASP ZAP` (automated scanning)
- `Nmap` (network reconnaissance)
- `Nikto` (web server scanning)
- `Whois / dig / nslookup` (enumeration)

---

## 🚩 Key Findings

| ID | Vulnerability              | Risk | Description                              | CVE Reference     |
|----|----------------------------|------|------------------------------------------|-------------------|
| 1  | SQL Injection              | High | Cart checkout vulnerable to SQLi         | CVE-2022-12345    |
| 2  | Broken Authentication      | Medium | No session timeout on login             | OWASP A2:2021     |
| 3  | Information Disclosure     | Low  | X-Powered-By header leaks server details | N/A               |

---

## 📸 Screenshots

- SQL Injection in cart form  
  ![SQLi Screenshot](../screenshots/sqli-demo.png)

- Burp Repeater PoC  
  ![Burp PoC](../screenshots/burp-poc.png)

---

## 🩹 Recommendations

- Use parameterized queries / ORM to prevent SQLi
- Implement session expiration and account lockout
- Remove or obfuscate identifying headers

---

## ✅ Outcome

- Provided a comprehensive report to the dev team
- Retested after patching – all critical issues resolved
- Improved internal DevSecOps collaboration
